Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:

* muestra-de_DE.po
* muestra-id_ID.po
* muestra-es_ES.po
* muestra-en_US.po

* muestra-de_DE.mo
* muestra-id_ID.mo
* muestra-es_ES.mo
* muestra-en_US.mo


Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download

<?php

/**

Plugin Name: Muestra 
Plugin URI: http://2389.tech/wp-maker/wordpress/ 
Description: Plugin Demo
Version: 1.0 
Author: 2389 Tech 
Author URI: http://2389.tech/wp-maker/wordpress/ 

Plugin Demo 

Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496

**/

# Exit if accessed directly
if (!defined("ABSPATH"))
{
	exit;
}

# Constant

/**
 * Exec Mode
 **/
define("MUE_EXEC",true);

/**
 * Plugin Base File
 **/
define("MUE_PATH",dirname(__FILE__));

/**
 * Plugin Base Directory
 **/
define("MUE_DIR",basename(MUE_PATH));

/**
 * Plugin Base URL
 **/
define("MUE_URL",plugins_url("/",__FILE__));

/**
 * Plugin Version
 **/
define("MUE_VERSION","1.0"); 

/**
 * Debug Mode
 **/
define("MUE_DEBUG",false);  //change false for distribution



/**
 * Base Class Plugin
 * @author 2389 Tech
 *
 * @access public
 * @version 1.0
 * @package Muestra
 *
 **/

class Muestra
{

	/**
	 * Instance of a class
	 * @access public
	 * @return void
	 **/

	function __construct()
	{
		add_action("plugins_loaded", array($this, "mue_textdomain")); //load language/textdomain
		add_action("wp_enqueue_scripts",array($this,"mue_enqueue_scripts")); //add js
		add_action("wp_enqueue_scripts",array($this,"mue_enqueue_styles")); //add css
		add_action("init", array($this, "mue_post_type_libro_init")); // register a libro post type.
		add_filter("the_content", array($this, "mue_post_type_libro_the_content")); // modif page for libro
		add_action("rest_prepare_libro", array($this, "mue_rest_prepare_libro"),10,3); 
		add_action("after_setup_theme", array($this, "mue_image_size")); // register image size.
		add_filter("image_size_names_choose", array($this, "mue_image_sizes_choose")); // image size choose.
		add_action("init", array($this, "mue_register_taxonomy")); // register register_taxonomy.
		add_action("wp_head",array($this,"mue_dinamic_js"),1); //load dinamic js
		if(is_admin()){
			add_action("add_meta_boxes",array($this,"mue_metabox_info_libro")); //add metabox Informacion Libro
			add_action("save_post",array($this,"mue_metabox_info_libro_save")); //save metabox Informacion Libro data
			add_action("admin_enqueue_scripts",array($this,"mue_admin_enqueue_scripts")); //add js for admin
			add_action("admin_enqueue_scripts",array($this,"mue_admin_enqueue_styles")); //add css for admin
		}
	}


	/**
	 * Loads the plugin's translated strings
	 * @link http://codex.wordpress.org/Function_Reference/load_plugin_textdomain
	 * @access public
	 * @return void
	 **/
	public function mue_textdomain()
	{
		load_plugin_textdomain("muestra", false, MUE_DIR . "/languages");
	}


	/**
	 * Add Metabox (info_libro)
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/add_meta_box
	 * @param mixed $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_metabox_info_libro($hook)
	{
		$allowed_hook = array("libro"); //limit meta box to certain page
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("mue_metabox_info_libro", __("Informacion Libro", "muestra"),array($this,"mue_metabox_info_libro_callback"),$hook,"normal","high");
		}
	}


	/**
	 * Create metabox markup (info_libro)
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/
	public function mue_metabox_info_libro_callback($post)
	{
		// Add a nonce field so we can check for it later.
		wp_nonce_field("mue_metabox_info_libro_save","mue_metabox_info_libro_nonce");
		if(file_exists(MUE_PATH . "/includes/metabox.info_libro.inc.php")){
			require_once(MUE_PATH . "/includes/metabox.info_libro.inc.php");
			$info_libro_metabox = new InfoLibro_Metabox();
			$info_libro_metabox->Markup($post);
		}
	}


	/**
	 *
	 * Save the meta when the post is saved.
	 * Muestra::mue_metabox_info_libro_save()
	 * @param int $post_id The ID of the post being saved.
	 *
	**/
	public function mue_metabox_info_libro_save($post_id)
	{

		/*
		 * We need to verify this came from the our screen and with proper authorization,
		 * because save_post can be triggered at other times.
		 */

		// Check if our nonce is set.
		if (!isset($_POST["mue_metabox_info_libro_nonce"]))
			return $post_id;
		$nonce = $_POST["mue_metabox_info_libro_nonce"];

		// Verify that the nonce is valid.
		if(!wp_verify_nonce($nonce, "mue_metabox_info_libro_save"))
			return $post_id;

		// If this is an autosave, our form has not been submitted,
		// so we don't want to do anything.
		if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
			return $post_id;

		// Check the user's permissions.
		if ("page" == $_POST["post_type"])
		{
			if (!current_user_can("edit_page", $post_id))
				return $post_id;
		} else
		{
			if (!current_user_can("edit_post", $post_id))
				return $post_id;
		}

		/* OK, its safe for us to save the data now. */

		// Sanitize the user input.
		//text
		$autor_libro = sanitize_text_field($_POST["mue_postmeta_autor_libro"] );

		// Update the meta field.
		update_post_meta($post_id, "_mue_postmeta_autor_libro", $autor_libro);

		// Sanitize the user input.
		//datepicker
		$fecha_pub_libro = sanitize_text_field($_POST["mue_postmeta_fecha_pub_libro"] );

		// Update the meta field.
		update_post_meta($post_id, "_mue_postmeta_fecha_pub_libro", $fecha_pub_libro);

		// Sanitize the user input.
		//text
		$editorial = sanitize_text_field($_POST["mue_postmeta_editorial"] );

		// Update the meta field.
		update_post_meta($post_id, "_mue_postmeta_editorial", $editorial);

	}




	/**
	 * Insert javascripts for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_admin_enqueue_scripts($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
	
		// limit page only libro
		if(( in_array($hooks,array("libro")))||( in_array($screen->post_type,array("libro")))){
			wp_enqueue_script("mue_admin_metabox", MUE_URL . "assets/js/mue_admin_metabox.js", array("jquery","thickbox","jquery-ui-core","jquery-ui-datepicker","wp-color-picker"),"1.0",true );
		}
	}


	/**
	 * Insert javascripts for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_enqueue_scripts($hooks)
	{
			wp_enqueue_script("mue_main", MUE_URL . "assets/js/mue_main.js", array("jquery"),"1.0",true );
	}


	/**
	 * Insert CSS for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_admin_enqueue_styles($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
		// register css
		wp_register_style("mue_metabox", MUE_URL . "assets/css/mue_admin_metabox.css",array(),"1.0" );
	
		// limit page
		if(( in_array($hooks,array("libro")))||( in_array($screen->post_type,array("libro")))){
			wp_enqueue_style("mue_metabox");
		}
		// register css
		wp_register_style("mue_jquery_ui", MUE_URL . "assets/third-party/jquery-ui/jquery-ui.min.css",array(),"1.0" );
	
		// limit page
		if(( in_array($hooks,array("libro")))||( in_array($screen->post_type,array("libro")))){
			wp_enqueue_style("mue_jquery_ui");
		}
		// register css
		wp_register_style("mue_jquery_ui_theme", MUE_URL . "assets/third-party/jquery-ui/jquery-ui.theme.min.css",array(),"1.0" );
	
		// limit page
		if(( in_array($hooks,array("libro")))||( in_array($screen->post_type,array("libro")))){
			wp_enqueue_style("mue_jquery_ui_theme");
		}
	}


	/**
	 * Insert CSS for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_enqueue_styles($hooks)
	{
		// register css
		wp_register_style("mue_main", MUE_URL . "assets/css/mue_main.css",array(),"1.0" );
			wp_enqueue_style("mue_main");
	}


	/**
	 * Register custom post types (libro)
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_post_type
	 * @access public
	 * @return void
	 **/

	public function mue_post_type_libro_init()
	{

		$labels = array(
			'name' => _x('Libros', 'post type general name', 'muestra'),
			'singular_name' => _x('Libro', 'post type singular name', 'muestra'),
			'menu_name' => _x('Libros', 'admin menu', 'muestra'),
			'name_admin_bar' => _x('Libros', 'add new on admin bar', 'muestra'),
			'add_new' => _x('Agregar', 'book', 'muestra'),
			'add_new_item' => __('Agregar Nuevo', 'muestra'),
			'new_item' => __('Nuevo', 'muestra'),
			'edit_item' => __('Editar', 'muestra'),
			'view_item' => __('Ver', 'muestra'),
			'all_items' => __('Ver Todos', 'muestra'),
			'search_items' => __('Buscar', 'muestra'),
			'parent_item_colon' => __('Tipo de libro', 'muestra'),
			'not_found' => __('No encontrado', 'muestra'),
			'not_found_in_trash' => __('No encontrado', 'muestra'));

			$supports = array('title','thumbnail');

			$args = array(
				'labels' => $labels,
				'description' => __('Libro', 'muestra'),
				'public' => true,
				'menu_icon' => 'dashicons-book-alt',
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'query_var' => true,
				'rewrite' => array('slug' => 'libro'),
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'show_in_rest' => true,
				'rest_base' => 'libro',
				'taxonomies' => array(), // array('category', 'post_tag','page-category'),
				'supports' => $supports);

			register_post_type('libro', $args);

		// create single template
		add_filter("single_template", array($this, "mue_post_type_libro_single_template"));

	}


	/**
	 * Load Single Template (libro)
	 *
	 * @access public
	 * @param mixed $single_template
	 * @return void
	 **/

	public function mue_post_type_libro_single_template($single_template)
	{

		global $post;
		if(file_exists(MUE_PATH . "/templates/single-libro.php" ))
		{
			if ($post->post_type == "libro")
			{
				$single_template = MUE_PATH . "/templates/single-libro.php";
			}
		}
		return $single_template;
	}


	/**
	 * Retrieved data custom post-types (libro)
	 *
	 * @access public
	 * @param mixed $content
	 * @return void
	 * @link https://codex.wordpress.org/Plugin_API/Filter_Reference/the_content
	 **/

	public function mue_post_type_libro_the_content($content)
	{

		$new_content = $content ;
		if(is_singular("libro")){
			if(file_exists(MUE_PATH . "/includes/post_type.libro.inc.php")){
				require_once(MUE_PATH . "/includes/post_type.libro.inc.php");
				$libro_content = new Libro_TheContent();
				$new_content = $libro_content->Markup($content);
				wp_reset_postdata();
			}
		}

		return $new_content ;

	}


	/**
	 * rest prepare
	 *
	 * @access public
	 * @param mixed $data
	 * @param mixed $term
	 * @param mixed $context
	 * @return void
	 * @link https://developer.wordpress.org/reference/hooks/rest_prepare_this-post_type/
	 **/

	public function mue_rest_prepare_libro($data,$term,$context)
	{
		$oldData = $data->data;
		$newData = $oldData;
		$newData["post_meta"] = get_post_meta($oldData["id"],"",true);
		$data->data = $newData;
		return $data;
	}


	/**
	 * Register a new image size.
	 * @link http://codex.wordpress.org/Function_Reference/add_image_size
	 * @access public
	 * @return void
	 **/
	public function mue_image_size()
	{
		add_image_size("mue_mythumbnail", 300, 400, true);
	}


	/**
	 * Choose a image size.
	 * @access public
	 * @param mixed $sizes
	 * @return void
	 **/
	public function mue_image_sizes_choose($sizes)
	{
		$custom_sizes = array(
				"mue_mythumbnail"=>"Imagen destacada",
		);
		return array_merge($sizes,$custom_sizes);
	}


	/**
	 * Register Taxonomies
	 * @https://codex.wordpress.org/Taxonomies
	 * @access public
	 * @return void
	 **/
	public function mue_register_taxonomy()
	{
		$categoria_libro_labels = array(
			"name" => _x( "Categorías", "taxonomy general name" ),
			"singular_name" => _x( "Categoría", "taxonomy singular name" ),
			"search_items" =>  __( "Search Categorías" ),
			"all_items" => __( "All Categorías" ),
			"parent_item" => __( "Parent Categoría" ),
			"parent_item_colon" => __( "Parent Categoría:" ),
			"edit_item" => __( "Edit Categoría" ),
			"update_item" => __( "Update Categoría" ),
			"add_new_item" => __( "Add New Categoría" ),
			"new_item_name" => __( "New Categoría Name" ),
			"menu_name" => __( "Categorías" ), 
		);
			
			
		register_taxonomy("categoria_libro",array("libro"), array(
			"hierarchical" => true,
			"labels" => $categoria_libro_labels,
			"show_ui" => true,
			"show_admin_column" => true,
			"query_var" => true,
			"rewrite" => array( "slug" => "categoria_libro" ),
		));
			
			
	}


	/**
	 * Insert Dinamic JS
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function mue_dinamic_js($hooks)
	{
		_e("<script type=\"text/javascript\">");
		_e("</script>");
	}
}


new Muestra();

=== Muestra ===

Contributors: 2389 Tech 
Donate link: http://ihsana.com
Tags:  demo
Requires at least: 5.0
Tested up to: 5.6
Stable tag: 6.0
License: GNU 2389
License URI: http://2389.tech/wp-maker/wordpress/

== Description ==
Plugin Demo

== Installation ==
1. Unzip and Upload `muestra.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make configuration setting in plugin setting page.
4. hit "save setting" button.

== Frequently asked questions ==
Q: I can not access page libro, it say error `Oops! That page can't be found.`
A: Go Settings Menu - permalink and click `Save Changes` again."

== Screenshots ==

== Changelog ==

== Credits ==

== Upgrade Notice == 
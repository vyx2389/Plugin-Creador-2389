/**
 * @Author :2389 Tech
 * @Author URL : http://2389.tech/wp-maker/wordpress/
 * @License : GNU 2389
 * @License URL: http://2389.tech/wp-maker/wordpress/
 *
 * @Package : Muestra
 * @Version : 1.0
**/


(function($)
{
	
	/**
	 * INFORMACION LIBRO
	 * name :info_libro
	 * postmeta : autor_libro
	 * label : Autor
	**/
	
	/**
	 * INFORMACION LIBRO
	 * name :info_libro
	 * postmeta : fecha_pub_libro
	 * label : Fecha de publicación
	**/
		
		/** datepicker api **/
		$(function(){
			$("#mue_postmeta_fecha_pub_libro").datepicker({dateFormat:"d MM, yy"});
		});
	
	/**
	 * INFORMACION LIBRO
	 * name :info_libro
	 * postmeta : editorial
	 * label : Editorial
	**/
})(jQuery);

<?php

/**
 * Metabox (Informacion Libro)
 *
**/

# Exit if accessed directly
if(!defined("MUE_EXEC")){
	die();
}


 /**
  * Dispaly back-end metabox info_libro
  * 
  * @package Muestra
  * @author 2389 Tech
  * @version 1.0
  * @access public
  * 
  * Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496
  */

class InfoLibro_Metabox{


	/**
	 * Option Plugin
	 * @access private
	 **/
	private $options;

	/**
	 * Instance of a class
	 * 
	 * @access public
	 * @return void
	 **/

	function __construct(){
		$this->options = get_option("muestra_plugins"); // get current option

	}

	/**
	 * Create Metabox Markup
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/

	public function Markup($post){

		// TODO: EDIT HTML METABOX INFORMACION LIBRO
		if(MUE_DEBUG==true){
			$file_info = null; 
			$file_info .= "<p>You can edit the file below to fix the metabox</p>" ; 
			$file_info .= "<div>" ; 
			$file_info .= "<pre style=\"color:rgba(255,0,0,1);padding:3px;margin:0px;background:rgba(255,0,0,0.1);border:1px solid rgba(255,0,0,0.5);font-size:11px;font-family:monospace;white-space:pre-wrap;\">%s:%s</pre>" ; 
			$file_info .= "</div>" ; 
			printf($file_info,__FILE__,__LINE__);
		}
		/**
		* You can make HTML tag for Metabox Informacion Libro here
		**/

		echo "<!-- <h4>Información del Libro</h4> -->";
		printf("<table class=\"form-table\">");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_mue_postmeta_autor_libro= get_post_meta($post->ID, "_mue_postmeta_autor_libro", true);

		/** Display the form autor_libro, using the current value. **/
		printf("<tr><th scope=\"row\"><label for=\"mue_postmeta_autor_libro\">%s</label></th><td><input class=\"mue-form-control\" type=\"text\" id=\"mue_postmeta_autor_libro\" name=\"mue_postmeta_autor_libro\" value=\"%s\" placeholder=\"Autor\" /></td></tr>",__("Autor", "muestra"), esc_attr($current_mue_postmeta_autor_libro));


		// Use get_post_meta to retrieve an existing value from the database.
		$current_mue_postmeta_fecha_pub_libro= get_post_meta($post->ID, "_mue_postmeta_fecha_pub_libro", true);

		/** Display the form fecha_pub_libro, using the current value. **/
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"mue mue-col-sm-2 mue-control-label\" for=\"mue_postmeta_fecha_pub_libro\">". __("Fecha de publicación", "muestra"). "</label></th>");
		printf("<td>");
		printf("<div class=\"mue\">");
		
		
		/**
		 * Create jQuery IU - Datepicker
		*/
		
		// need these styles
		wp_enqueue_style("jquery-ui-datepicker");
		// create form input
		printf("<input class='mue-form-control' id='mue_postmeta_fecha_pub_libro' type='text' name='mue_postmeta_fecha_pub_libro' value='%s'/><p class='description'>". __(" ","mue-textdomain") . "</p>",$current_mue_postmeta_fecha_pub_libro);
		printf("</div>");
		printf("</td>");
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_mue_postmeta_editorial= get_post_meta($post->ID, "_mue_postmeta_editorial", true);

		/** Display the form editorial, using the current value. **/
		printf("<tr><th scope=\"row\"><label for=\"mue_postmeta_editorial\">%s</label></th><td><input class=\"mue-form-control\" type=\"text\" id=\"mue_postmeta_editorial\" name=\"mue_postmeta_editorial\" value=\"%s\" placeholder=\"Editorial\" /></td></tr>",__("Editorial", "muestra"), esc_attr($current_mue_postmeta_editorial));
		echo "</table>";
	}
}
